import base64
import boto3
import hmac
import hashlib

def lambda_handler(event, context):
    try:
        print(event)
        auth_header = event['headers']['authorization']
        method_arn = event['routeArn']

        print("auth_header: " + auth_header)
        print("method_arn: " + method_arn)
        
        # Extract and decode 'Basic base64(user:pass)'
        encoded = auth_header.split(' ')[1]
        decoded = base64.b64decode(encoded).decode('utf-8')
        username, password = decoded.split(':')
        print("username: " + username)
        print("password: " + password)

        # Cognito Customer Data
        client_id = '3743b4sreb7ioddklg8c9528n7'
        client_secret = 'tq1v20kkldqdn8vq0gsb5jri863o20cntue87tvui0e47dvtv0r'  

        # Calculate SECRET_HASH
        message = username + client_id
        digest = hmac.new(
            client_secret.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).digest()
        secret_hash = base64.b64encode(digest).decode()

        # Authentication against Cognito
        client = boto3.client('cognito-idp')
        client.admin_initiate_auth(
            UserPoolId='us-east-1_gxVIMUbPo',
            ClientId=client_id,
            AuthFlow='ADMIN_NO_SRP_AUTH',
            AuthParameters={
                'USERNAME': username,
                'PASSWORD': password,
                'SECRET_HASH': secret_hash
            }
        )

        # If passed, returns Allow
        return {
            "isAuthorized": True,
            "context": {
                "user": username
            }
        }

    except Exception as e:
        print(e)
        return {
            "isAuthorized": False
        }
