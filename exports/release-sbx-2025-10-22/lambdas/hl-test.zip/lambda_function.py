import json
import boto3

def lambda_handler(event, context):
    print(f"Boto3 version: {boto3.__version__}")
    print(f"Event: {event}")
    print(f"Context: {context}")
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
